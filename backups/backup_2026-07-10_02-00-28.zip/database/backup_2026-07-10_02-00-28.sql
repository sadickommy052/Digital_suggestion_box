-- ===========================================
-- Digital Suggestion Box System Backup
-- Generated: 2026-07-10 02:00:28
-- ===========================================

SET FOREIGN_KEY_CHECKS=0;

-- --------------------------------------------------------
-- Table: `activity_logs`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `activity_logs`;
CREATE TABLE `activity_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `activity_logs` (`log_id`, `user_id`, `username`, `action`, `details`, `ip_address`, `user_agent`, `created_at`) VALUES
('53', '2', 'omega', 'Backup Restored', 'Restored backup: backup_2026-07-10_01-40-15.sql', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-09 21:41:46'),
('54', '2', 'omega', 'Backup Created', 'Complete backup created: backup_2026-07-10_01-44-07.zip (7 tables + files)', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-09 21:44:07'),
('55', '2', 'omega', 'Backup Created', 'Complete backup created: backup_2026-07-10_01-44-24.zip (7 tables + files)', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-09 21:44:25'),
('56', '2', 'omega', 'Backup Deleted', 'Deleted backup: backup_2026-07-10_01-44-07.zip', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-09 21:44:36'),
('57', '2', 'omega', 'Backup Deleted', 'Deleted backup: backup_2026-07-10_01-40-15.sql', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36', '2026-07-09 21:44:43');

-- --------------------------------------------------------
-- Table: `attachments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `attachments`;
CREATE TABLE `attachments` (
  `attachment_id` int(11) NOT NULL AUTO_INCREMENT,
  `suggestion_id` int(11) NOT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`attachment_id`),
  KEY `attachments_ibfk_1` (`suggestion_id`),
  CONSTRAINT `attachments_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `suggestions` (`suggestion_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `attachments` (`attachment_id`, `suggestion_id`, `file_name`, `file_path`, `file_type`, `uploaded_at`) VALUES
('31', '98', 'Contact Form UI Design _ Lignt and Dark Mode _ Boltstack_dev.jpeg', 'uploads/file_6a50384c54f1a5.96096709.jpeg', 'jpeg', '2026-07-09 20:09:48'),
('32', '99', 'ideas.jpeg', 'uploads/file_6a503ca788e207.25250695.jpeg', 'jpeg', '2026-07-09 20:28:23');

-- --------------------------------------------------------
-- Table: `categories`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `category_name` (`category_name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `categories` (`category_id`, `category_name`, `description`, `created_at`) VALUES
('1', 'Academic', NULL, '2026-06-01 10:20:34'),
('2', 'ICT / Technology', NULL, '2026-06-01 10:20:34'),
('4', 'Administrative Services', NULL, '2026-06-01 10:20:34'),
('5', 'Student Life', NULL, '2026-06-01 10:20:34'),
('7', 'Ideas', NULL, '2026-06-01 10:20:34'),
('8', 'others', NULL, '2026-06-01 10:20:34');

-- --------------------------------------------------------
-- Table: `comments`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL AUTO_INCREMENT,
  `suggestion_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`comment_id`),
  KEY `idx_comments_suggestion_id` (`suggestion_id`),
  KEY `idx_comments_user_id` (`user_id`),
  KEY `idx_comments_created_at` (`created_at`),
  CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`suggestion_id`) REFERENCES `suggestions` (`suggestion_id`) ON DELETE CASCADE,
  CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

-- --------------------------------------------------------
-- Table: `notifications`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`notification_id`),
  KEY `notifications_ibfk_1` (`user_id`),
  CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `notifications` (`notification_id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
('96', '3', 'New Suggestion Submitted', 'A new suggestion \'tusome\' has been submitted by juma. Please review it.', 'new_suggestion', '0', '2026-07-09 19:49:21'),
('97', '15', 'Suggestion Approved', 'Your suggestion \'tusome\' has been approved.', 'suggestion_approved', '0', '2026-07-09 19:50:41'),
('98', '3', 'New Suggestion Submitted', 'A new suggestion \'wifi\' has been submitted by juma. Please review it.', 'new_suggestion', '0', '2026-07-09 20:09:48'),
('99', '3', 'New Suggestion Submitted', 'A new suggestion \'wifi\' has been submitted by ommy. Please review it.', 'new_suggestion', '0', '2026-07-09 20:28:23'),
('100', '3', 'New Suggestion Submitted', 'A new suggestion \'gjdgjdhjgjd\' has been submitted by ommy. Please review it.', 'new_suggestion', '0', '2026-07-09 20:38:05'),
('101', '15', 'New Suggestion Submitted', 'A new suggestion \'gjdgjdhjgjd\' has been submitted by ommy. Please review it.', 'new_suggestion', '0', '2026-07-09 20:38:05'),
('102', '3', 'New Suggestion Submitted', 'A new suggestion \'fjfhgjdgdg\' has been submitted by ommy. Please review it.', 'new_suggestion', '0', '2026-07-09 21:00:47'),
('103', '15', 'New Suggestion Submitted', 'A new suggestion \'fjfhgjdgdg\' has been submitted by ommy. Please review it.', 'new_suggestion', '0', '2026-07-09 21:00:47');

-- --------------------------------------------------------
-- Table: `suggestions`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `suggestions`;
CREATE TABLE `suggestions` (
  `suggestion_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `status` enum('pending','in_review','approved','rejected','implemented') DEFAULT 'pending',
  `visibility` enum('public','private') DEFAULT 'public',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`suggestion_id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `suggestions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `suggestions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `suggestions` (`suggestion_id`, `user_id`, `category_id`, `title`, `message`, `status`, `visibility`, `created_at`, `updated_at`) VALUES
('97', '15', '1', 'tusome', 'tusome', 'approved', 'public', '2026-07-09 19:49:21', '2026-07-09 19:50:41'),
('98', '15', '2', 'wifi', 'improve wifi speed', 'pending', 'public', '2026-07-09 20:09:48', NULL),
('99', '1', '2', 'wifi', 'jhfgfkljfglfjgdsgjsd', 'pending', 'public', '2026-07-09 20:28:23', NULL),
('100', '1', '5', 'gjdgjdhjgjd', 'djkgkdgdfgflfhk', 'pending', 'public', '2026-07-09 20:38:04', NULL),
('101', '1', '4', 'fjfhgjdgdg', 'steyeteuetuet', 'pending', 'public', '2026-07-09 21:00:47', NULL);

-- --------------------------------------------------------
-- Table: `users`
-- --------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('suggester','suggestion_manager','admin') DEFAULT 'suggester',
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `profile_picture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;

INSERT INTO `users` (`user_id`, `full_name`, `email`, `password`, `role`, `status`, `created_at`, `profile_picture`) VALUES
('1', 'ommy', 'ommy@gmail.com', '$2y$12$o9NaVlHj9IFazAYXycqMF.5Z4ljy0n./xrnsrTVOhky8JTFKxaJzy', 'suggester', 'active', '2026-06-01 09:46:28', 'uploads/1783081193_Inventory Management - Dashboard - Web Application - nirmal kumar.jpeg'),
('2', 'omega', 'omega@gmail.com', '$2y$12$v3SjgkzvW5AbbCDctFNua.Glc.2Sr.QqwSupG8sDW6F3932OelUKS', 'admin', 'active', '2026-06-01 10:02:59', 'uploads/1783639985_ideas.jpeg'),
('3', 'elia', 'elia@gmail.com', '$2y$12$/k8Oin9G13QES5S4m3P9GugcaTROJbTrQ7M348lw4dia.4Y2jmOZK', 'suggestion_manager', 'active', '2026-06-01 10:22:17', 'uploads/1783095524_download.jpeg'),
('15', 'juma', 'juma@gmail.com', '$2y$12$jX3uv9iegRPPf7VOREQsIOTihG4biGDvIZjCUh/hGjvrg1FsEiAka', 'suggestion_manager', 'active', '2026-07-09 19:39:04', NULL);

SET FOREIGN_KEY_CHECKS=1;
